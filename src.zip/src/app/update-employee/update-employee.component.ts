import { Component, OnInit } from '@angular/core';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { Employee } from '../employee';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../employee.service';



@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.sass']
})
export class UpdateEmployeeComponent implements OnInit {

  id: number;
  employee: Employee;
  dropdownList = [];
  selectedItems = [];
  selectedSkills = []
  dropdownSettings:IDropdownSettings;
  
  constructor(private route: ActivatedRoute,private router: Router,
  private employeeService: EmployeeService) { }

  ngOnInit() {
    this.employee = new Employee();

    this.dropdownList = [
      { id: 1, item_text: 'Java' },
      { id: 2, item_text: 'Python' },
      { id: 3, item_text: 'PHP' },
      { id: 4, item_text: 'AWS' },
      { id: 5, item_text: 'HMTL' }
    ];
    this.selectedItems = [
      { id: 3, item_text: 'PHP' },
      { id: 4, item_text: 'AWS' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'id',
      textField: 'item_text',
      enableCheckAll: true,
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true,
      maxHeight:150
    };
    

    this.id = this.route.snapshot.params['id'];
    
    this.employeeService.getEmployee(this.id)
      .subscribe(data => {
        console.log(data)
        this.employee = data;
      }, error => console.log(error));

  }

  updateEmployee() {
    console.log(this.dropdownList);
    this.employeeService.updateEmployee(this.id, this.employee)
      .subscribe(data => console.log(data), error => console.log(error));
    this.employee = new Employee();
    this.gotoList();
  }

  onSubmit() {
    this.updateEmployee();    
  }

  gotoList() {
    this.router.navigate(['/employees']);
  }
  onItemSelect(item: any) {
    this.selectedSkills.push(item.item_text);
    console.log(item);
  }
  onItemUnSelect (item: any) {
    const index = this.selectedSkills.indexOf(item.item_text);
    if (index > -1) {
      this.selectedSkills.splice(index, 1);
    }
  }
  onSelectAll(items: any) {
    console.log(items);
    items.forEach(i => {
      this.selectedSkills.push(i.item_text);
    });
  }
  onUnSelectAll() {
    while (this.selectedSkills.length) {
      this.selectedSkills.pop();
    }
  
  }
}